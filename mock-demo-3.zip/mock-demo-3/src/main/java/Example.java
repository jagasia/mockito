public class Example
{
	Maths maths;
	
	public Example(Maths maths) {
		super();
		this.maths = maths;
	}

	public int compute(int x, int y)
	{
		int result=maths.sum(x,y);
		return result;
	}
}