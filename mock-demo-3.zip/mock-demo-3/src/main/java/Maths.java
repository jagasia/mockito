public interface Maths
{
	int sum(int i, int j);
}