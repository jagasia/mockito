import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class ExampleTest
{
	static Maths maths;
	static Example ex;
	
	@BeforeClass
	public static void setup()
	{
		maths=mock(Maths.class);
		ex=new Example(maths);
		when(maths.sum(3,3)).thenReturn(6);
		when(maths.sum(2,3)).thenReturn(5);
		when(maths.sum(13, 13)).thenReturn(26);
	}
	
	@Test
	public void testSum1()
	{
		int result=ex.compute(2,3);
		assertEquals(5,result);		
	}
	
	@Test
	public void testSum2()
	{
		int result=ex.compute(3,3);
		assertEquals(6,result);
	}
	@Test
	public void testSum3()
	{
		int result=ex.compute(13,13);
		assertEquals(26,result);
	}
	
}